from __future__ import absolute_import
from __future__ import print_function
from __future__ import division

import sys
import matplotlib
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d
from numpy.lib.arraysetops import intersect1d
from tqdm import tqdm
# Load image
import imageio


# Set random seed so output is all same
np.random.seed(1)

def pairwise_dist(x, y):
    """
    Args:
        x: N x D numpy array
        y: M x D numpy array
    Return:
        dist: N x M array, where dist2[i, j] is the euclidean distance between
        x[i, :] and y[j, :]
    """

    return np.linalg.norm(x[:, None, :] - y[None, :, :], axis=-1)

class KMeans(object):

    def __init__(self): #No need to implement
        pass

    def _init_centers(self, points, K, **kwargs): # [5 pts]
        """
        Args:
            points: NxD numpy array, where N is # points and D is the dimensionality
            K: number of clusters
            kwargs: any additional arguments you want
        Return:
            centers: K x D numpy array, the centers.
        """
        return points[np.random.choice(points.shape[0], K, replace=False)]

    def _update_assignment(self, centers, points): # [10 pts]
        """
        Args:
            centers: KxD numpy array, where K is the number of clusters, and D is the dimension
            points: NxD numpy array, the observations
        Return:
            cluster_idx: numpy array of length N, the cluster assignment for each point

        Hint: You could call pairwise_dist() function.
        """
        distsToCenters = pairwise_dist(points, centers)
        cluster_idx = np.argmin(distsToCenters,axis=1)
        return cluster_idx

    def _update_centers(self, old_centers, cluster_idx, points): # [10 pts]
        """
        Args:
            old_centers: old centers KxD numpy array, where K is the number of clusters, and D is the dimension
            cluster_idx: numpy array of length N, the cluster assignment for each point
            points: NxD numpy array, the observations
        Return:
            centers: new centers, K x D numpy array, where K is the number of clusters, and D is the dimension.
        """
        centers = np.empty(old_centers.shape)
        for center in range(0,old_centers.shape[0]):
            centers[center] = np.average(points, axis=0,weights=(cluster_idx==center))

        return centers

    def _get_loss(self, centers, cluster_idx, points): # [5 pts]
        """
        Args:
            centers: KxD numpy array, where K is the number of clusters, and D is the dimension
            cluster_idx: numpy array of length N, the cluster assignment for each point
            points: NxD numpy array, the observations
        Return:
            loss: a single float number, which is the objective function of KMeans.
        """

        loss = 0
        for center in range(0,centers.shape[0]):
            points_in_section = points[center==cluster_idx]
            lossToPoints = pairwise_dist(points_in_section,np.expand_dims(centers[center],0))
            loss += np.sum(np.square(lossToPoints))

        return loss


    def __call__(self, points, K, max_iters=100, abs_tol=1e-16, rel_tol=1e-16, verbose=False, **kwargs):
        """
        Args:
            points: NxD numpy array, where N is # points and D is the dimensionality
            K: number of clusters
            max_iters: maximum number of iterations (Hint: You could change it when debugging)
            abs_tol: convergence criteria w.r.t absolute change of loss
            rel_tol: convergence criteria w.r.t relative change of loss
            verbose: boolean to set whether method should print loss (Hint: helpful for debugging)
            kwargs: any additional arguments you want
        Return:
            cluster assignments: Nx1 int numpy array
            cluster centers: K x D numpy array, the centers
            loss: final loss value of the objective function of KMeans
        """
        centers = self._init_centers(points, K, **kwargs)
        for it in range(max_iters):
            cluster_idx = self._update_assignment(centers, points)
            centers = self._update_centers(centers, cluster_idx, points)
            loss = self._get_loss(centers, cluster_idx, points)
            K = centers.shape[0]
            if it:
                diff = np.abs(prev_loss - loss)
                if diff < abs_tol and diff / prev_loss < rel_tol:
                    break
            prev_loss = loss
            if verbose:
                print('iter %d, loss: %.4f' % (it, loss))
        return cluster_idx, centers, loss

def find_optimal_num_clusters(data, max_K=19): # [10 pts]
    """Plots loss values for different number of clusters in K-Means

    Args:
        image: input image of shape(H, W, 3)
        max_K: number of clusters
    Return:
        List with loss values
    """
    loss_values = []
    x = np.arange(19)+1
    for k in x:
        cluster_idx, centers, loss = KMeans()(data, k)
        loss_values.append(loss)

    plt.xticks(np.arange(0, max_K+1, 1.0))
    plt.plot(x,loss_values)
    return loss_values



def intra_cluster_dist(cluster_idx, data, labels): # [4 pts]
    """
    Calculates the average distance from a point to other points within the same cluster

    Args:
        cluster_idx: the cluster index (label) for which we want to find the intra cluster distance
        data: NxD numpy array, where N is # points and D is the dimensionality
        labels: 1D array of length N where each number indicates of cluster assignement for that point
    Return:
        intra_dist_cluster: 1D array where the i_th entry denotes the average distance from point i
                            in cluster denoted by cluster_idx to other points within the same cluster
    """
    intra_cluster_points = data[labels==cluster_idx]
    dists = pairwise_dist(intra_cluster_points,intra_cluster_points)

    return np.sum(dists,axis=1)/(intra_cluster_points.shape[0]-1)


def inter_cluster_dist(cluster_idx, data, labels): # [4 pts]
    """
    Calculates the average distance from one cluster to the nearest cluster
    Args:
        cluster_idx: the cluster index (label) for which we want to find the intra cluster distance
        data: NxD numpy array, where N is # points and D is the dimensionality
        labels: 1D array of length N where each number indicates of cluster assignement for that point
    Return:
        inter_dist_cluster: 1D array where the i-th entry denotes the average distance from point i in cluster
                            denoted by cluster_idx to the nearest neighboring cluster
    """
    # Calculate dist to each cluster for each point
    intra_cluster_points = data[labels==cluster_idx]
    inter_dists = []
    for k in range(0,np.max(labels)+1):
        if k == cluster_idx:
            continue
        inter_cluster_pts = data[k==labels]
        dists = pairwise_dist(intra_cluster_points,inter_cluster_pts)
        avg_dists = np.mean(dists,axis=1)
        inter_dists.append(avg_dists)

    return np.min(inter_dists,axis=0)
def normalized_cut(data, labels): #[2 pts]
    """
    Finds the normalized_cut of the current cluster assignment

    Args:
        data: NxD numpy array, where N is # points and D is the dimensionality
        labels: 1D array of length N where each number indicates of cluster assignement for that point
    Return:
        normalized_cut: normalized cut of the current cluster assignment
    """
    cut_sum = 0
    for k in range(0,np.max(labels)+1):
        inter = inter_cluster_dist(k,data,labels)
        intra = intra_cluster_dist(k,data,labels)
        cut_sum += np.sum(inter/(intra+inter))
    return cut_sum
